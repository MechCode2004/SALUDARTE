#include <ESP8266WiFi.h>
#include <SoftwareSerial.h>
#include "DFRobotDFPlayerMini.h"
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Ticker.h>  // Librería para temporizadores no bloqueantes

#define PIN_D8 15  // D8 en NodeMCU es GPIO15
#define PIN_LED_D5 14 // D5 en NodeMCU es GPIO14

// Definir constantes
#define ANCHO_PANTALLA 128 // Ancho pantalla OLED
#define ALTO_PANTALLA 64   // Alto pantalla OLED

// Configuración WiFi
const char* ssid = "LIRIVI";  
const char* password = "12102002";

// Variable para almacenar la IP anterior y evitar refrescos innecesarios
String ipAnterior = "";

// Objeto de la clase Adafruit_SSD1306
Adafruit_SSD1306 display(ANCHO_PANTALLA, ALTO_PANTALLA, &Wire, -1);

// Servidor Web
WiFiServer server(80);

// DFPlayer Mini
static const uint8_t PIN_MP3_TX = 13;  // D7 en NodeMCU
static const uint8_t PIN_MP3_RX = 12;  // D6 en NodeMCU
SoftwareSerial softwareSerial(PIN_MP3_RX, PIN_MP3_TX);
DFRobotDFPlayerMini player;

// Pines de sensores magnéticos
const int SENSOR_D0 = 16; // D0 en NodeMCU
const int SENSOR_D3 = 0;  // D3 en NodeMCU
const int SENSOR_D4 = 2;  // D4 en NodeMCU

// Variables de estado de sensores
bool contandoD0 = false, contandoD3 = false, contandoD4 = false;
bool tiempoCumplidoD0 = false, tiempoCumplidoD3 = false, tiempoCumplidoD4 = false;

// Ticker para manejar temporizadores de los sensores
Ticker temporizadorD0, temporizadorD3, temporizadorD4;

// Callbacks que se ejecutan después de 10 minutos
void activarD0() { 
  Serial.println("Sensor D0 alcanzó los 10 minutos. Reproduciendo Audio 13.");
  tiempoCumplidoD0 = true;  
}

void activarD3() { 
  Serial.println("Sensor D3 alcanzó los 10 minutos. Reproduciendo Audio 14.");
  tiempoCumplidoD3 = true;
}

void activarD4() { 
  Serial.println("Sensor D4 alcanzó los 10 minutos. Reproduciendo Audio 15.");
  tiempoCumplidoD4 = true;
}

void setup() {
  Serial.begin(115200);
  softwareSerial.begin(9600);
  delay(1000);

  pinMode(PIN_D8, OUTPUT);
  digitalWrite(PIN_D8, LOW); // Asegurar que el RELE esté apagado al inicio

  pinMode(PIN_LED_D5, OUTPUT);
  digitalWrite(PIN_LED_D5, LOW); // Asegurar que el LED esté apagado al inicio

  pinMode(SENSOR_D0, INPUT_PULLUP);
  pinMode(SENSOR_D3, INPUT_PULLUP);
  pinMode(SENSOR_D4, INPUT_PULLUP);

  // Iniciar pantalla OLED
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("No se encuentra la pantalla OLED");
    while (true);
  }

  // Limpiar pantalla OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  Serial.println("Conectando a WiFi...");
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConectado a WiFi!");
  Serial.print("IP del ESP8266: ");
  Serial.println(WiFi.localIP());

  // Mostrar IP en pantalla OLED
  actualizarPantalla(WiFi.localIP().toString());

  delay(1000);  // Esperar antes de inicializar DFPlayer Mini
  server.begin();

  bool mp3Inicializado = false;

  // Iniciar DFPlayer Mini
  Serial.println("Iniciando DFPlayer Mini...");
  if (player.begin(softwareSerial)) {
    Serial.println("DFPlayer Mini conectado correctamente.");
    player.volume(30);  // Ajustar volumen (0 a 30)
    mp3Inicializado = true;
  } else {
    Serial.println("Error al conectar DFPlayer Mini. Verifica conexiones.");
  }

  // Encender el LED D5 si WiFi y DFPlayer Mini se inicializaron correctamente
  if (WiFi.status() == WL_CONNECTED && mp3Inicializado) {
    digitalWrite(PIN_LED_D5, HIGH);
    Serial.println("WiFi y MP3 inicializados correctamente. LED encendido.");
  }
}

void loop() {
  // Actualizar IP en pantalla si cambió
  String ipActual = WiFi.localIP().toString();
  if (ipActual != ipAnterior) {
    actualizarPantalla(ipActual);
    ipAnterior = ipActual;
  }

  // Verificar sensores
  verificarSensores();

  // Manejo de clientes HTTP
  WiFiClient client = server.available();
  if (client) {
    Serial.println("Cliente conectado.");
    String request = client.readStringUntil('\r');
    Serial.println("Comando recibido: " + request);

    // Enviar una respuesta HTTP válida al cliente
    client.println("HTTP/1.1 200 OK");
    client.println("Content-Type: text/html");
    client.println();
    client.println("OK");

    // Encender el LED antes de reproducir
    digitalWrite(PIN_D8, HIGH);
    delay(500); 

    if (request.indexOf("/AUDIO1") >= 0) reproducirAudio(1);
    else if (request.indexOf("/AUDIO2") >= 0) reproducirAudio(2);
    else if (request.indexOf("/AUDIO3") >= 0) reproducirAudio(3);
    else if (request.indexOf("/AUDIO4") >= 0) reproducirAudio(4);
    else if (request.indexOf("/AUDIO5") >= 0) reproducirAudio(5);
    else if (request.indexOf("/AUDIO6") >= 0) reproducirAudio(6);
    else if (request.indexOf("/AUDIO7") >= 0) reproducirAudio(7);
    else if (request.indexOf("/AUDIO8") >= 0) reproducirAudio(8);
    else if (request.indexOf("/AUDIO9") >= 0) reproducirAudio(9);
    else if (request.indexOf("/AUDIOA") >= 0) reproducirAudio(10);
    else if (request.indexOf("/AUDIOB") >= 0) reproducirAudio(11);
    else if (request.indexOf("/AUDIOC") >= 0) reproducirAudio(12);

    client.stop();
    Serial.println("Cliente desconectado.");
  }

  delay(500);
}

// Función para verificar sensores y gestionar Ticker
void verificarSensores() {
  if (tiempoCumplidoD0) {
    reproducirAudio(13);
    tiempoCumplidoD0 = false;
  }
  if (tiempoCumplidoD3) {
    reproducirAudio(14);
    tiempoCumplidoD3 = false;
  }
  if (tiempoCumplidoD4) {
    reproducirAudio(15);
    tiempoCumplidoD4 = false;
  }
}

void actualizarPantalla(String ip) {
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SSD1306_WHITE);

  display.setCursor(10, 20);
  display.println("CONECTADO A LA RED");

  display.setCursor(0, 40);
  display.print("IP: ");
  display.println(ip);

  display.display();
}

void reproducirAudio(int numero) {
  digitalWrite(PIN_D8, HIGH);
  Serial.printf("Reproduciendo Audio %d\n", numero);
  delay(100);
  player.play(numero);
  delay(9000);
  digitalWrite(PIN_D8, LOW);
}
